import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static SharedPreferences? _prefs;
  static const _keyLoggedIn = 'logged_in';
  static const _keyUserEmail = 'user_email';

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static bool isLoggedIn() {
    return _prefs?.getBool(_keyLoggedIn) ?? false;
  }

  static String? getUserEmail() {
    return _prefs?.getString(_keyUserEmail);
  }

  static Future<void> login(String email) async {
    await _prefs?.setBool(_keyLoggedIn, true);
    await _prefs?.setString(_keyUserEmail, email);
  }

  static Future<void> logout() async {
    await _prefs?.setBool(_keyLoggedIn, false);
    await _prefs?.remove(_keyUserEmail);
  }
}