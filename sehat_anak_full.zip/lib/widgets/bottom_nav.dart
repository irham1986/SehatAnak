import 'package:flutter/material.dart';

class BottomNav extends StatelessWidget {
  final int currentIndex;
  final void Function(int) onTap;
  final VoidCallback onProfileTap;

  const BottomNav({required this.currentIndex, required this.onTap, required this.onProfileTap});

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      elevation: 12,
      shape: CircularNotchedRectangle(),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 8),
        child: Row(
          children: [
            IconButton(
              icon: Icon(Icons.home, color: currentIndex == 0 ? Theme.of(context).colorScheme.primary : Colors.black54),
              onPressed: () => onTap(0),
            ),
            IconButton(
              icon: Icon(Icons.search, color: currentIndex == 1 ? Theme.of(context).colorScheme.primary : Colors.black54),
              onPressed: () => onTap(1),
            ),
            Spacer(),
            IconButton(
              icon: Icon(Icons.notifications, color: currentIndex == 2 ? Theme.of(context).colorScheme.primary : Colors.black54),
              onPressed: () => onTap(2),
            ),
            IconButton(
              icon: Icon(Icons.person, color: currentIndex == 3 ? Theme.of(context).colorScheme.primary : Colors.black54),
              onPressed: onProfileTap,
            ),
          ],
        ),
      ),
    );
  }
}