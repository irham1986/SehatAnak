import 'package:flutter/material.dart';

class NutritionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String imagePath;

  const NutritionCard({required this.title, required this.subtitle, required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 6),
                Text(subtitle, style: TextStyle(color: Colors.black54)),
              ]),
            ),
            SizedBox(width: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(imagePath, width: 76, height: 76, fit: BoxFit.cover),
            )
          ],
        ),
      ),
    );
  }
}