import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  static const routeName = '/detail';
  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>? ?? {};
    final title = args['title'] ?? 'Detail Artikel';

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        leading: BackButton(),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset('assets/images/hero_bg.png', width: double.infinity, height: 180, fit: BoxFit.cover),
            ),
            SizedBox(height: 12),
            Text(title, style: Theme.of(context).textTheme.headline6?.copyWith(fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Oleh: Tim SehatAnak • 12 Okt 2025', style: TextStyle(color: Colors.black54, fontSize: 13)),
            SizedBox(height: 12),
            Text(
              'Ini bagian isi artikel; tuliskan penjelasan tentang nutrisi, langkah pencegahan stunting, tabel gizi, atau panduan interaktif. Kamu bisa mengganti konten ini dengan data dinamis dari backend nanti.',
              style: TextStyle(height: 1.5),
            ),
            SizedBox(height: 18),
            ElevatedButton(
              onPressed: () {},
              child: Text('Simpan Artikel'),
            ),
            SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}