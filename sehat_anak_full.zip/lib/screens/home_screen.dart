import 'package:flutter/material.dart';
import '../widgets/header_card.dart';
import '../widgets/nutrition_card.dart';
import '../widgets/bottom_nav.dart';
import 'detail_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  static const routeName = '/';
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    HomeContent(),
    Center(child: Text('Cari / Search (placeholder)')),
    Center(child: Text('Notifikasi (placeholder)')),
    Center(child: Text('Lainnya (placeholder)')),
  ];

  void _onNavTap(int idx) {
    setState(() {
      _selectedIndex = idx;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNav(
        currentIndex: _selectedIndex,
        onTap: _onNavTap,
        onProfileTap: () {
          Navigator.pushNamed(context, ProfileScreen.routeName);
        },
      ),
    );
  }
}

class HomeContent extends StatelessWidget {
  const HomeContent({Key? key}) : super(key: key);

  void _openDetail(BuildContext context, String title) {
    Navigator.pushNamed(context, DetailScreen.routeName, arguments: {'title': title});
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            HeaderCard(),
            SizedBox(height: 20),
            Text("Tips Nutrisi", style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            GestureDetector(
              onTap: () => _openDetail(context, 'Pentingnya ASI Eksklusif'),
              child: NutritionCard(
                title: "Pentingnya ASI Eksklusif",
                subtitle: "Selama 6 bulan pertama untuk tumbuh kembang optimal",
                imagePath: "assets/images/placeholder_child.png",
              ),
            ),
            SizedBox(height: 10),
            GestureDetector(
              onTap: () => _openDetail(context, 'Menu Seimbang 1-3 Tahun'),
              child: NutritionCard(
                title: "Menu Seimbang 1-3 Tahun",
                subtitle: "Protein, karbohidrat, lemak sehat, sayur & buah",
                imagePath: "assets/images/hero_bg.png",
              ),
            ),
            SizedBox(height: 24),
            Text("Layanan", style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: ElevatedButton(onPressed: () {}, child: Text("Laporkan Kasus"))),
                SizedBox(width: 10),
                Expanded(child: OutlinedButton(onPressed: () {}, child: Text("Cek Status Anak"))),
              ],
            ),
            SizedBox(height: 24),
            Text("Artikel Populer", style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            SizedBox(
              height: 120,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  SizedBox(width: 4),
                  _ArticleTile(title: 'Gizi Ibu Hamil', subtitle: 'Penting untuk tumbuh kembang awal'),
                  SizedBox(width: 12),
                  _ArticleTile(title: 'Perkenalan Makanan Padat', subtitle: 'Kapan & bagaimana'),
                  SizedBox(width: 12),
                  _ArticleTile(title: 'Cek Tumbuh Kembang', subtitle: 'Indikator penting'),
                ],
              ),
            ),
            SizedBox(height: 36),
          ],
        ),
      ),
    );
  }
}

class _ArticleTile extends StatelessWidget {
  final String title;
  final String subtitle;
  const _ArticleTile({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, DetailScreen.routeName, arguments: {'title': title});
      },
      child: Container(
        width: 220,
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0,4))],
        ),
        child: Row(
          children: [
            ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/images/placeholder_child.png', width: 72, height: 72, fit: BoxFit.cover)),
            SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              Text(subtitle, style: TextStyle(color: Colors.black54, fontSize: 13)),
            ])),
          ],
        ),
      ),
    );
  }
}