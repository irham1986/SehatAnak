import 'package:flutter/material.dart';
import '../../utils/auth_service.dart';
import 'register_screen.dart';
import '../home_screen.dart';

class LoginScreen extends StatefulWidget {
  static const routeName = '/login';
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _emailCtl = TextEditingController();
  final _pwCtl = TextEditingController();
  bool _loading = false;

  void _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);
    await Future.delayed(Duration(milliseconds: 700));
    await AuthService.login(_emailCtl.text.trim());
    setState(() => _loading = false);
    Navigator.pushReplacementNamed(context, HomeScreen.routeName);
  }

  @override
  void dispose() {
    _emailCtl.dispose();
    _pwCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Masuk'),
        leading: Container(),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            SizedBox(height: 12),
            Text('Selamat datang di SehatAnak', style: Theme.of(context).textTheme.headline6),
            SizedBox(height: 8),
            Text('Masuk untuk melihat tips & catatan tumbuh kembang', style: TextStyle(color: Colors.black54)),
            SizedBox(height: 18),
            Form(
              key: _form,
              child: Column(
                children: [
                  TextFormField(
                    controller: _emailCtl,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(labelText: 'Email'),
                    validator: (v) => v != null && v.contains('@') ? null : 'Masukkan email valid',
                  ),
                  SizedBox(height: 12),
                  TextFormField(
                    controller: _pwCtl,
                    obscureText: true,
                    decoration: InputDecoration(labelText: 'Kata Sandi'),
                    validator: (v) => v != null && v.length >= 6 ? null : 'Minimal 6 karakter',
                  ),
                  SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _loading ? null : _submit,
                      child: _loading ? CircularProgressIndicator(color: Colors.white) : Text('Masuk'),
                    ),
                  ),
                  SizedBox(height: 12),
                  TextButton(
                    onPressed: () => Navigator.pushNamed(context, RegisterScreen.routeName),
                    child: Text('Belum punya akun? Daftar'),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}