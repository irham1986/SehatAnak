import 'package:flutter/material.dart';
import '../utils/auth_service.dart';

class ProfileScreen extends StatelessWidget {
  static const routeName = '/profile';
  @override
  Widget build(BuildContext context) {
    final email = AuthService.getUserEmail() ?? 'pengguna@contoh.com';
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil Saya'),
        leading: BackButton(),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(children: [
              CircleAvatar(radius: 36, backgroundImage: AssetImage('assets/images/placeholder_child.png')),
              SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(email, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                SizedBox(height: 4),
                Text('Ibu / Ayah • Kota Contoh', style: TextStyle(color: Colors.black54)),
              ])
            ]),
            SizedBox(height: 20),
            Card(
              child: ListTile(
                leading: Icon(Icons.child_care),
                title: Text('Data Anak'),
                subtitle: Text('Atur profil anak & catatan tumbuh kembang'),
                onTap: () {},
              ),
            ),
            Card(
              child: ListTile(
                leading: Icon(Icons.settings),
                title: Text('Pengaturan'),
                subtitle: Text('Notifikasi, bahasa, bantuan'),
                onTap: () {},
              ),
            ),
            Spacer(),
            ElevatedButton(
              onPressed: () async {
                await AuthService.logout();
                Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
              },
              child: Text('Keluar'),
              style: ElevatedButton.styleFrom(minimumSize: Size(double.infinity, 48)),
            ),
          ],
        ),
      ),
    );
  }
}